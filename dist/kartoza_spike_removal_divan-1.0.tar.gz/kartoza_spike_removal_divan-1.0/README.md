# Polygon spike removal

Remove spikes from polygons, curvepolygons, multipolygons, and multisurface polygons. 



# Installation

GitHub: https://github.com/vermeulendivan/polygon_spike_removal


